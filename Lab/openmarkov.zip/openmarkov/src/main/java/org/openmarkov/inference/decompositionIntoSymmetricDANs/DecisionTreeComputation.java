package org.openmarkov.inference.decompositionIntoSymmetricDANs;

import org.openmarkov.core.dt.DecisionTreeNode;

public interface DecisionTreeComputation {
	
	public DecisionTreeNode getDecisionTree();

}
